window.addEventListener('load', () => {
  const f = document.getElementById('file1');
  f.addEventListener('change', evt => {
    var file_name = f.files[0]
    console.log(file_name)
    let input = evt.target;
    if (input.files.length == 0) {
      console.warn('No file selected');
      return;
    }
    var file = f.files[0];
    console.log(file)
    const reader = new FileReader();
    reader.onload = () => {
      const pre = document.getElementById('pre1');
      pre.innerHTML = reader.result;
    };
    const input_ = document.getElementById("input")
    const header = document.getElementById("header")
    input_.style.display = "none";
    reader.readAsText(file);
    header.innerHTML =
      '<div class="tab">'
      + '<input type="button" class="button" value="ファイル">'
      + '<input type="button" class="button" value="印刷" onclick="window.print();">'
      + '<input tyle="button" class="button" id="hideEn" value="英文を隠す" onclick="hideEnglish();">'
      + '<input tyle="button" class="button" value="アプリをリセット">'


      + '<input tyle="button" class="close" value="✕" style="float: right;  width: 38px;" onclick="window.close(this)">'
            +'<input tyle="button" class="button white" value="" style="float:right; width:38px;">'
            +'<input tyle="button" class="button white" value="―" style="float:right;width:38px;">'
      + '</div>';
  });
});
let style = 0;
function hideEnglish() {
  var elem = document.getElementById("PageStyleSheet");
  var hideEn = document.getElementById("hideEn");
  switch (style) {
    case 0:
      elem.href = "styleHideEn.css";
      hideEn.innerTEXT="英文を再表示";
      style=1;
      break;
    case 1:
      elem.href="stylesheet.css"; //存在しないが変更のため使用。
      hideEn.innerTEXT="英文を隠す";
      style=0;
      break;
  }
};