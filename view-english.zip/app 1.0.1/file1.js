window.addEventListener('load', () => {
  const f = document.getElementById('file1');
  f.addEventListener('change', evt => {
    var file_name = f.files[0]
    let input = evt.target;
    if (input.files.length == 0) {
      console.warn('No file selected');
      return;
    }
    var file = f.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      const pre = document.getElementById('pre1');
      pre.innerHTML = reader.result;
    };
    const input_ = document.getElementById("input")
    const header = document.getElementById("header")
    input_.style.display = "none";
    reader.readAsText(file);
    header.innerHTML =
      '<div class="tab">' +
        '<div class="tab-left">' +
          '<input type="button" class="button button-left" value="ファイル">' +
          '<input type="button" class="button button-left" value="印刷" onclick="window.print();">' +
          '<input tyle="button" class="button button-left" id="hideEn" value="英文を隠す" onclick="hideEnglish();">' +
          '<input tyle="button" class="button button-left" value="アプリをリセット">' +
        '</div>' +
        '<div class="tab-right">'+
          '<input tyle="button" class="button button-right" value="" >'+
          '<input tyle="button" class="button button-right" value="">'+
          '<input tyle="button" class="button button-right close" value="✕" onclick="window.close(this)">'+
        '</div>'+
      '</div>';
  });
});
let style = 0;
function hideEnglish() {
  var elem = document.getElementById("PageStyleSheet");
  var hideEn = document.getElementById("hideEn");
  switch (style) {
    case 0:
      elem.href = "styleHideEn.css";
      hideEn.innerTEXT = "英文を再表示";
      style = 1;
      break;
    case 1:
      elem.href = "test.css";//実際には存在しないが変更先として登録
      hideEn.innerTEXT = "英文を隠す";
      style = 0;
      break;
  }
};