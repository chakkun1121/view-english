//const hotkeys = require('hotkeys');
import cookies from 'js-cookie';
window.onload = function() {
  //初期設定
  let style=0;
  //cookieの中にdataURLがあれば用意し、change_htmlに投げる。なければパス
  const dataURL=cookies.get('fileURL');
  if (!dataURL) {
  // do something
    change_html(dataURL);
}
  
}
function view_file(){
//ファイルが選択されたときに行う
  //ファイルをdetaURLにする
  const file = document.querySelector('input[type=file]').files[0];
  const reader = new FileReader();

  reader.addEventListener("load", function () {
    // ファイルを base64 文字列に変換します
     const fileURL = reader.result;
      console.log(fileURL);
    //dataURLをcookieに投げる
    const cookie_fileURL= encodeURIComponent(fileURL)
    document.cookie='fileURL='+cookie_fileURL;
    //html表示
      change_html(fileURL);
  }, false);

  if (file) {
    reader.readAsDataURL(file);
  }
  return;  
}
function change_html(dataURL){
  //dataURLをUTN-8に変
    //const file_8=decodeURIComponent(atob(dataURL));
    //console.log(file_8);
  //dataURLを利用し、表示。
    const input_ = document.getElementById("input");
    const header = document.getElementById("header");
    const output= document.getElementById("output");
    input_.style.display = "none";
    header.innerHTML =
      '<div class="tab">' +
        '<div class="tab-left">' +
          '<input type="button" class="button button-left" value="ファイル">' /*+
          '<label class="button-label button button-left"><input type="file" class="tab-file"><p  style="font-size:8px;">ファイルを開く</p></label>'*/
          +'<input type="button" class="button button-left" value="印刷" onclick="window.print();">' +
          '<input tyle="button" class="button button-left" id="hideEn" value="英文を隠す/再表示" onclick="hideEnglish();">' +
          '<input tyle="button" class="button button-left" value="アプリをリセット" onclick="location.reload();">' +
        '</div>' +
        '<div class="tab-right">'+/*
          '<input tyle="button" class="button button-right" value="-">'+
          '<input tyle="button" class="button button-right" value="&#xf24d;">'+*/
          '<input tyle="button" class="button button-right close" value="✕" onclick="window.close(this);">'+
        '</div>'+
      '</div>';
      output.innerHTML='<iframe src='+dataURL+'>'
}
/*
//キーボードショートカット作成
hotkeys('ctrl+a,ctrl+b,r,f', function (event, handler){
  switch (handler.key) {
    case 'ctrl+a': 
      break;
    case 'ctrl+b': alert('you pressed ctrl+b!');
      break;
    case 'r': alert('you pressed r!');
      break;
    case 'f': alert('you pressed f!');
      break;
    default: alert(event);
  }
});
*/
/*
function hideEnglish() {
  switch (style) {
    case 0:
      html_style.innerHTML = '<style>.en{color:white;}</style>';
      style = 1;
      break;
    case 1:
      html_style.innerHTML="";
      style = 0;
      break;
  }
}*/
function hideEnglish() {
    var elem = document.getElementById("PageStyleSheet");
  switch (style) {
    case 0:
      elem.href = "styleHideEn.css";
      style = 1;
      break;
    case 1:
      elem.href = "404.css";//実際には存在しないが変更先として登録
      style = 0;
      break;
  }
};