window.onload = function() {
  // ページ読み込み時に実行したい処理
  console.clear;
  const contents = document.getElementById('contents');
  home();
};
function home() {
  //document.getElementById("back").style.display = "none";

  mode = "home"
  contents.innerHTML =
    '<input type="button" value="使い方" class="button" onclick="how_to_use()">'
    + '<div class=button>'
    + '<input type="button" value="アプリを使い始める(ページを移動します。)" class="button"  onclick="start_app();">'
    + '</div>';
}
function start_app() {
  window.open('https://view-english.chakkun1121haru.repl.co/app/app.html','_blank')
}
function how_to_use(){
  var how_to_use_=document.getElementById("how_to_use")
  how_to_use_.innerHTML='<div class="subtitle"><h2>使い方</h2></div><p>1.和訳ファイル(htmlもしくは.wayaku)を準備します。</p><p>2.アプリを使い始めるを押し、和訳ファイルをアップロードします。</p><p>3.その後は指示に従い使用します。</p><p>4.最後に✕ボタンを押し、アプリを終了します。</p>';
}
